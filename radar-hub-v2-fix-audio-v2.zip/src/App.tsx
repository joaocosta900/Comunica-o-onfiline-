/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';

const PUBLIC_AGENCIES = [
  { label: "Polícia Militar (190)", number: "190", desc: "Crimes em andamento, agressões, ameaças à vida e roubos." },
  { label: "SAMU (192)", number: "192", desc: "Urgências médicas, acidentes graves, problemas cardíacos, traumas." },
  { label: "Corpo de Bombeiros (193)", number: "193", desc: "Incêndios, resgates, acidentes de trânsito com vítimas presas." },
  { label: "Defesa Civil (199)", number: "199", desc: "Desastres naturais, desabamentos, enchentes, risco de desmoronamento." },
  { label: "Polícia Rod. Federal (191)", number: "191", desc: "Acidentes e crimes nas rodovias federais." },
  { label: "Polícia Civil (197)", number: "197", desc: "Investigações, informações sobre crimes já ocorridos." },
  { label: "Disque Denúncia (181)", number: "181", desc: "Denúncias anônimas de crimes, tráfico e esconderijos." },
  { label: "CVV (188)", number: "188", desc: "Apoio emocional e prevenção do suicídio (24h)." },
  { label: "Delegacia da Mulher (180)", number: "180", desc: "Denúncias de violência contra a mulher." },
  { label: "Familiar / Parente", number: "", desc: "Contato pessoal de confiança." },
  { label: "Amigo(a)", number: "", desc: "Contato pessoal para emergências." },
  { label: "Outro", number: "", desc: "Outro tipo de contato personalizado." }
];

export default function App() {
  const [logs, setLogs] = useState([
    "[SCANNER] Waiting for scan initiation...",
    "[OES] Rendering surface is ready."
  ]);
  const [showLogs, setShowLogs] = useState(true);
  const [devices, setDevices] = useState<any[]>([]);
  const [view, setView] = useState<'radar' | 'hub' | 'sos'>('radar');

  // Hub States
  const [chatMessages, setChatMessages] = useState<{sender: string, text: string, file?: any}[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [files, setFiles] = useState<any[]>([]);
  const wsRef = useRef<WebSocket | null>(null);

  // Voice message (mic) states
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioStreamRef = useRef<MediaStream | null>(null);
  const recordingTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // SOS States
  const [sosActive, setSosActive] = useState(false);
  const [sosBroadcastToChat, setSosBroadcastToChat] = useState(false);
  const [gpsData, setGpsData] = useState<{lat: number, lng: number, acc: number, time: string} | null>(null);
  const [peerSosData, setPeerSosData] = useState<{lat: number, lng: number, acc: number, time: string, date: string} | null>(null);
  const [sosPanelExpanded, setSosPanelExpanded] = useState(false);
  const [gpsStatus, setGpsStatus] = useState<string>("Aguardando ativação...");
  const [networkStatus, setNetworkStatus] = useState<{internet: boolean, local: boolean, sms: boolean}>({
    internet: navigator.onLine,
    local: true,
    sms: true,
  });
  const [emergencyContacts, setEmergencyContacts] = useState<{name: string, number: string, description?: string, active: boolean}[]>([]);
  const [newContact, setNewContact] = useState({name: "", number: "", description: ""});
  const [editingContactIndex, setEditingContactIndex] = useState<number | null>(null);

  useEffect(() => {
    // Libera microfone/gravação pendente se o componente for desmontado
    return () => {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      audioStreamRef.current?.getTracks().forEach(t => t.stop());
    };
  }, []);

  useEffect(() => {
    const handleOnline = () => setNetworkStatus(prev => ({...prev, internet: true}));
    const handleOffline = () => setNetworkStatus(prev => ({...prev, internet: false}));
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const saved = localStorage.getItem('sosContacts');
    if (saved) {
      setEmergencyContacts(JSON.parse(saved));
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    }
  }, []);

  const saveContacts = (contacts: any[]) => {
    setEmergencyContacts(contacts);
    localStorage.setItem('sosContacts', JSON.stringify(contacts));
  };

  const addContact = () => {
    if (!newContact.name || !newContact.number) return;
    if (editingContactIndex !== null) {
      const updated = [...emergencyContacts];
      updated[editingContactIndex] = { ...updated[editingContactIndex], ...newContact };
      saveContacts(updated);
      setEditingContactIndex(null);
    } else {
      saveContacts([...emergencyContacts, { ...newContact, active: true }]);
    }
    setNewContact({name: "", number: "", description: ""});
  };

  const editContact = (index: number) => {
    setNewContact({
      name: emergencyContacts[index].name,
      number: emergencyContacts[index].number,
      description: emergencyContacts[index].description || ""
    });
    setEditingContactIndex(index);
  };

  const cancelEdit = () => {
    setNewContact({name: "", number: "", description: ""});
    setEditingContactIndex(null);
  };

  const removeContact = (index: number) => {
    saveContacts(emergencyContacts.filter((_, i) => i !== index));
  };

  const toggleContact = (index: number) => {
    const updated = [...emergencyContacts];
    updated[index].active = !updated[index].active;
    saveContacts(updated);
  };

  const [realtimeInterval, setRealtimeInterval] = useState(10);
  const [customMessage, setCustomMessage] = useState("Preciso de ajuda. Esta é uma mensagem de emergência.");
  const watchIdRef = useRef<number | null>(null);
  const lastUpdateRef = useRef<number>(0);

  const stopSOS = () => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    setSosActive(false);
    setGpsStatus("Aguardando ativação...");
    setLogs(prev => [...prev, "[SOS] Modo de emergência CANCELADO."]);
  };

  const testSOS = async () => {
    setLogs(prev => [...prev, "[SOS TEST] Executando simulação de emergência..."]);
    const simGps = { lat: -23.5505, lng: -46.6333, acc: 10, time: new Date().toLocaleTimeString() };
    setGpsData(simGps);
    setGpsStatus("🟢 GPS disponível (Simulação)");
    
    // Simula estado sem internet
    setNetworkStatus({ internet: false, local: true, sms: true });
    
    setLogs(prev => [
      ...prev, 
      "[SOS TEST] GPS: OK", 
      `[SOS TEST] Contatos: ${emergencyContacts.length}`, 
      "[SOS TEST] Internet: Offline", 
      "[SOS TEST] SMS: Pronto",
      "[SOS TEST] Resultado: Sistema preparado para emergência. Enviando SMS de teste..."
    ]);

    for (const contact of emergencyContacts) {
      if (!contact.active) continue;
      try {
        const mapLink = `https://www.google.com/maps/search/?api=1&query=${simGps.lat},${simGps.lng}`;
        const testMsg = `[TESTE] 🚨 ALERTA DE EMERGÊNCIA 🚨\n${customMessage}\nMinha localização atual:\nLatitude: ${simGps.lat}\nLongitude: ${simGps.lng}\nLocalização no mapa:\n${mapLink}`;
        const res = await fetch(`http://127.0.0.1:8000/api/sos/sms`, {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({ number: contact.number, message: testMsg })
        });
        const data = await res.json();
        if (data.status === 'success') {
          setLogs(prev => [...prev, `[SOS TEST] SMS DE TESTE enviado para ${contact.name}`]);
        } else {
          setLogs(prev => [...prev, `[SOS TEST] Falha SMS para ${contact.name}: ${data.message}`]);
        }
      } catch(e) {
        setLogs(prev => [...prev, `[SOS TEST] Falha de rede local ao enviar SMS de teste para ${contact.name}`]);
      }
    }
  };

  const activateSOS = () => {
    setSosActive(true);
    setLogs(prev => [...prev, "[SOS] Inicializando modo de emergência..."]);
    lastUpdateRef.current = 0;
    
    if ("geolocation" in navigator) {
      setGpsStatus("Obtendo localização...");

      
      const handlePosition = async (position: GeolocationPosition) => {
        const { latitude, longitude, accuracy } = position.coords;
        const now = Date.now();
        const time = new Date().toLocaleTimeString();
        const date = new Date().toLocaleDateString();
        
        setGpsData({ lat: latitude, lng: longitude, acc: accuracy, time: `${date} ${time}` });
        setGpsStatus("🟢 GPS disponível");

        // Throttle updates based on realtimeInterval (0 = tempo real, sem espera)
        if (realtimeInterval > 0 && now - lastUpdateRef.current < realtimeInterval * 1000) {
          return;
        }
        lastUpdateRef.current = now;
        
        setLogs(prev => [...prev, `[SOS] GPS Atualizado: ${latitude.toFixed(6)}, ${longitude.toFixed(6)}`]);

        const mapLink = `https://www.google.com/maps/search/?api=1&query=${latitude},${longitude}`;
        const message = `🚨 ALERTA DE EMERGÊNCIA 🚨\n${customMessage}\nMinha localização atual:\nLatitude: ${latitude}\nLongitude: ${longitude}\nPrecisão aproximada: ${accuracy.toFixed(0)} metros\nData: ${date}\nHora: ${time}\nLocalização no mapa:\n${mapLink}`;

        if (sosBroadcastToChat && wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
          wsRef.current.send(`🚨EMERGENCIA🚨|${latitude}|${longitude}|${accuracy.toFixed(0)}|${time}|${date}`);
        }

        if (networkStatus.internet) {
          setLogs(prev => [...prev, "[SOS] Rastreamento em tempo real (Internet)..."]);
          // Here we would typically send to a server endpoint for real-time tracking
          // For now, the WebSocket handles local network real-time sharing.
        } else {
          setLogs(prev => [...prev, "[SOS] Sem internet, tentando SMS via servidor local Termux..."]);
          for (const contact of emergencyContacts) {
            if (!contact.active) continue;
            try {
              const res = await fetch(`http://127.0.0.1:8000/api/sos/sms`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ number: contact.number, message: message })
              });
              const data = await res.json();
              if (data.status === 'success') {
                setLogs(prev => [...prev, `[SOS] SMS enviado para ${contact.name}`]);
              } else {
                setLogs(prev => [...prev, `[SOS] Falha SMS para ${contact.name}: ${data.message}`]);
                setNetworkStatus(prev => ({...prev, sms: false}));
              }
            } catch(e) {
              setLogs(prev => [...prev, `[SOS] Falha de rede local ao enviar SMS para ${contact.name}`]);
            }
          }
        }
      };

      const handleError = (error: GeolocationPositionError) => {
        setGpsStatus("🔴 Falha ao obter GPS: " + error.message);
        setLogs(prev => [...prev, `[SOS] Erro GPS: ${error.message}`]);
      };

      // Watch position for continuous updates
      watchIdRef.current = navigator.geolocation.watchPosition(
        handlePosition,
        handleError,
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
      );
    } else {
      setGpsStatus("🔴 GPS não suportado neste navegador");
    }
  };

  const initHub = () => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;
    try {
      const host = window.location.hostname;
      const ws = new WebSocket(`ws://${host}:8000/ws/chat`);
      ws.onmessage = (event) => {
        const data = event.data as string;
        if (data.startsWith('[FILE]')) {
          const fname = data.slice(6);
          const ext = fname.split('.').pop()?.toLowerCase() || '';
          const isAudio = ['weba', 'ogg', 'oga', 'm4a', 'mp3', 'wav'].includes(ext) || fname.startsWith('voz_');
          const isImage = !isAudio && ['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext);
          const isVideo = !isAudio && ['mp4', 'mov', 'webm'].includes(ext);
          const fileUrl = `http://${host}:8000/download/${fname}`;
          setChatMessages(prev => [...prev, {
            sender: 'Peer',
            text: isAudio ? `Mensagem de voz` : `Arquivo enviado: ${fname}`,
            file: { name: fname, url: fileUrl, isImage, isVideo, isAudio }
          }]);
          fetchFiles(host);
        } else if (data.startsWith('🚨EMERGENCIA🚨')) {
          const parts = data.split('|');
          setPeerSosData({
            lat: parseFloat(parts[1]),
            lng: parseFloat(parts[2]),
            acc: parseFloat(parts[3]),
            time: parts[4],
            date: parts[5]
          });
        } else {
          setChatMessages(prev => [...prev, {sender: 'Peer', text: data}]);
        }
      };
      ws.onopen = () => {
        setLogs(prev => [...prev, "[HUB] Conectado ao servidor Offline Python (Termux)."]);
      };
      wsRef.current = ws;
      fetchFiles(host);
    } catch(e) {
      setLogs(prev => [...prev, "[HUB] Erro ao conectar no servidor Python. Iniciando modo simulação."]);
      setFiles([{name: "termo_de_uso.pdf"}, {name: "foto_reuniao.jpg"}, {name: "app_v2.apk"}]);
    }
  };

  const fetchFiles = async (host: string) => {
    try {
      const res = await fetch(`http://${host}:8000/files`);
      const data = await res.json();
      setFiles((data.files || []).map((f: string) => ({name: f})));
    } catch(e) {
      setLogs(prev => [...prev, "[HUB] API de arquivos indisponível. Mock carregado."]);
      setFiles([{name: "termo_de_uso.pdf"}, {name: "foto_reuniao.jpg"}, {name: "app_v2.apk"}]);
    }
  };

  const sendChatMessage = () => {
    if(!chatInput) return;
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(chatInput);
      setChatMessages(prev => [...prev, {sender: 'Me', text: chatInput}]);
    } else {
      setChatMessages(prev => [...prev, {sender: 'Me', text: chatInput}]);
      setTimeout(() => setChatMessages(prev => [...prev, {sender: 'Peer', text: `Mock Echo: ${chatInput}`}]), 500);
    }
    setChatInput("");
  };

  const deleteChatMessage = (index: number) => {
    setChatMessages(prev => prev.filter((_, i) => i !== index));
  };

  const deleteFile = (fileName: string) => {
    setFiles(prev => prev.filter(f => (f.name || f) !== fileName));
  };

  const sendFileMessage = async (file: File, opts?: { label?: string }) => {
    const formData = new FormData();
    formData.append("file", file);

    setLogs(prev => [...prev, `[HUB] Processando arquivo: ${file.name}`]);

    const isImage = file.type.startsWith('image/');
    const isVideo = file.type.startsWith('video/');
    const isAudio = file.type.startsWith('audio/');
    const url = URL.createObjectURL(file);
    const label = opts?.label || `Arquivo enviado: ${file.name}`;

    try {
      await fetch(`http://${window.location.hostname}:8000/upload`, {
        method: "POST",
        body: formData
      });
      fetchFiles(window.location.hostname);
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(`[FILE]${file.name}`);
      }
      setLogs(prev => [...prev, `[HUB] Arquivo enviado via LAN: ${file.name}`]);
      setChatMessages(prev => [...prev, {
        sender: 'Me',
        text: label,
        file: { name: file.name, url, isImage, isVideo, isAudio }
      }]);
    } catch(err) {
      setLogs(prev => [...prev, `[HUB] Simulação: Envio de ${file.name} simulado com sucesso.`]);

      setFiles(prev => {
        if (!prev.find(f => f.name === file.name)) {
          return [...prev, { name: file.name, url, isImage, isVideo, isAudio }];
        }
        return prev;
      });
      setChatMessages(prev => [...prev, {
        sender: 'Me',
        text: label,
        file: { name: file.name, url, isImage, isVideo, isAudio }
      }]);
    }
  };

  const uploadFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if(!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    await sendFileMessage(file);
    // Clear input so the same file can be selected again
    e.target.value = '';
  };

  // --- Mensagem de voz (microfone) ---
  const pickBestAudioMime = () => {
    // Prioriza codecs com melhor compressão/qualidade percebida para voz (Opus)
    const candidates = [
      'audio/webm;codecs=opus',
      'audio/ogg;codecs=opus',
      'audio/mp4;codecs=mp4a.40.2',
      'audio/webm',
      'audio/mp4',
    ];
    for (const type of candidates) {
      if (typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported?.(type)) {
        return type;
      }
    }
    return '';
  };

  const startRecording = async () => {
    if (isRecording) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          channelCount: 1,
          sampleRate: 48000,
        }
      });
      audioStreamRef.current = stream;
      const mimeType = pickBestAudioMime();
      const recorder = new MediaRecorder(stream, {
        ...(mimeType ? { mimeType } : {}),
        audioBitsPerSecond: 256000, // alta qualidade para voz (Opus @256kbps é essencialmente transparente)
      });
      audioChunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      recorder.onstop = () => {
        const finalMime = recorder.mimeType || mimeType || 'audio/webm';
        const blob = new Blob(audioChunksRef.current, { type: finalMime });
        const ext = finalMime.includes('ogg') ? 'ogg' : finalMime.includes('mp4') ? 'm4a' : 'webm';
        const fileName = `voz_${Date.now()}.${ext}`;
        const audioFile = new File([blob], fileName, { type: finalMime });

        stream.getTracks().forEach(t => t.stop());
        audioStreamRef.current = null;

        if (blob.size > 0) {
          sendFileMessage(audioFile, { label: 'Mensagem de voz' });
        }
      };

      recorder.start();
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
      setRecordingSeconds(0);
      recordingTimerRef.current = setInterval(() => setRecordingSeconds(s => s + 1), 1000);
      setLogs(prev => [...prev, "[HUB] Gravando mensagem de voz..."]);
    } catch (err: any) {
      setLogs(prev => [...prev, `[HUB] Erro ao acessar microfone: ${err.message}`]);
    }
  };

  const stopRecording = () => {
    if (!isRecording) return;
    mediaRecorderRef.current?.stop();
    setIsRecording(false);
    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
    setLogs(prev => [...prev, "[HUB] Mensagem de voz finalizada."]);
  };

  const toggleRecording = () => {
    if (isRecording) stopRecording();
    else startRecording();
  };

  const interceptAudioStream = () => {
    setLogs(prev => [
      ...prev,
      "[A2DP_SNOOP] Tentando sintonizar canal de áudio...",
      "[ERRO] Bloqueio de Segurança: O áudio Bluetooth (A2DP) usa conexão pareada ponto-a-ponto criptografada (E0/AES-CCM).",
      "[SYS] Conclusão: É tecnicamente impossível 'escutar' a música de outro fone apenas via software de celular sem um hardware SDR externo."
    ]);
  };

  const transmitTvSignal = () => {
    setLogs(prev => [
      ...prev,
      "[TX_SIGNAL] Preparando payload de desligamento da TV...",
      "[HARDWARE_CHECK] Buscando emissor Infravermelho (IR Blaster)... NÃO ENCONTRADO.",
      "[AVISO] O Moto G54 5G não possui hardware de infravermelho.",
      "[SYS] Alternativa 1: Pareamento Bluetooth HID (atuar como teclado/controle Bluetooth).",
      "[SYS] Alternativa 2: Enviar pacote Wake-on-LAN / API Rest via rede Wi-Fi local."
    ]);
  };

  const scanForDevices = async () => {
    try {
      if (!navigator.bluetooth) {
        setLogs(prev => [
          ...prev, 
          "[ERROR] Web Bluetooth não suportado neste navegador/iframe.",
          "[SYS] O radar real requer o APK nativo do Android.",
          "[SYS] Iniciando simulação..."
        ]);
        
        setTimeout(() => {
          const simulatedDevice = {
            name: 'Simulated Audio Device',
            id: 'mock-' + Math.random().toString(36).substr(2, 9),
            rssi: -45 - Math.floor(Math.random() * 20),
            distance: (Math.random() * 3 + 1).toFixed(1)
          };
          setDevices(prev => [...prev, simulatedDevice]);
          setLogs(prev => [...prev, `[SIMULATION] Encontrou: ${simulatedDevice.name}`]);
        }, 1500);
        return;
      }
      
      setLogs(prev => [
        ...prev, 
        "[SCANNER] Iniciando Web Bluetooth...",
        "[AVISO] O navegador SÓ mostra dispositivos BLE (Low Energy). Fones de ouvido clássicos podem não aparecer aqui. Para achar tudo, use o APK nativo!"
      ]);
      
      const device = await navigator.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: ['battery_service', 'device_information']
      });

      const newDevice = {
        name: device.name || 'Unknown Device',
        id: device.id,
        rssi: -50 - Math.floor(Math.random() * 40),
        distance: (Math.random() * 5 + 1).toFixed(1)
      };

      setDevices(prev => {
        if (!prev.find(d => d.id === newDevice.id)) {
          return [...prev, newDevice];
        }
        return prev;
      });

      setLogs(prev => [...prev, `[BLE] Dispositivo selecionado: ${newDevice.name}`]);

      // Attempt mock connection
      device.addEventListener('gattserverdisconnected', () => {
        setLogs(prev => [...prev, `[BLE] Desconectado: ${newDevice.name}`]);
      });

    } catch (e: any) {
      setLogs(prev => [...prev, `[ERROR] ${e.message}`, "[DICA] Para o radar completo, compile o projeto Kotlin via Termux/GitHub Actions."]);
    }
  };

  return (
    <div className="w-full h-dvh bg-[#0B0D14] text-[#E6E9F2] font-mono flex flex-col overflow-hidden">
      {/* Top Navigation / Status Bar */}
      <header className="py-2 md:py-0 md:h-14 shrink-0 border-b border-[#232838] flex flex-col md:flex-row md:items-center justify-between px-4 md:px-6 bg-[#171A26] gap-2 md:gap-0">
        <div className="flex items-center space-x-4">
          <div className="relative w-3 h-3 flex items-center justify-center shrink-0">
            <span className="radar-sweep absolute w-[26px] h-[26px] rounded-full"></span>
            <span className="relative z-[1] w-3 h-3 rounded-full bg-[#2DE1E6] shadow-[0_0_8px_#2DE1E6]"></span>
          </div>
          <h1 className="font-display text-base md:text-lg font-bold uppercase truncate">BLE.RADAR // MVP-OES</h1>
          <span className="text-[10px] bg-[#232838] px-2 py-0.5 rounded text-[#7C8798] hidden sm:inline-block shrink-0">BUILD_05.42 // MOTO_G54</span>
        </div>
        <div className="flex items-center space-x-2 md:space-x-4 text-[9px] md:text-[11px] overflow-x-auto w-full md:w-auto pb-1 md:pb-0 hide-scrollbar">
          
          <button onClick={() => setView('radar')} className={`shrink-0 px-3 py-1 border rounded transition-colors ${view === 'radar' ? 'bg-[#2DE1E6]/12 text-[#2DE1E6] border-[#2DE1E6]' : 'border-[#232838] text-[#7C8798] hover:bg-[#232838]'}`}>
            RADAR
          </button>
          <button onClick={() => { setView('hub'); initHub(); }} className={`shrink-0 px-3 py-1 border rounded transition-colors ${view === 'hub' ? 'bg-[#5EA1FF]/12 text-[#5EA1FF] border-[#5EA1FF]' : 'border-[#232838] text-[#7C8798] hover:bg-[#232838]'}`}>
            OFFLINE HUB
          </button>
          <button onClick={() => setView('sos')} className={`shrink-0 px-3 py-1 border rounded transition-colors font-bold ${view === 'sos' ? 'bg-[#EF4444]/12 text-[#EF4444] border-[#EF4444]' : 'border-[#232838] text-[#EF4444] hover:bg-[#232838]'}`}>
            🚨 EMERGÊNCIA
          </button>

          {view === 'radar' && (
            <>
              <button 
                onClick={scanForDevices}
                className="shrink-0 rounded bg-[#2DE1E6]/12 text-[#2DE1E6] border border-[#2DE1E6] px-3 py-1 hover:bg-[#2DE1E6]/25 cursor-pointer transition-colors"
              >
                + ADD AUDIO/BT DEVICE
              </button>
              <button 
                onClick={interceptAudioStream}
                className="shrink-0 rounded bg-[#F5B940]/12 text-[#F5B940] border border-[#F5B940] px-3 py-1 hover:bg-[#F5B940]/25 cursor-pointer transition-colors"
              >
                INTERCEPTAR ÁUDIO
              </button>
              <button 
                onClick={transmitTvSignal}
                className="shrink-0 rounded bg-[#EF4444]/12 text-[#EF4444] border border-[#EF4444] px-3 py-1 hover:bg-[#EF4444]/25 cursor-pointer transition-colors"
              >
                DESLIGAR TV
              </button>
            </>
          )}

          <div className="flex flex-col items-start md:items-end shrink-0 ml-4">
            <span className="text-[#7C8798] uppercase">Scan Mode</span>
            <span className="text-[#2DE1E6]">BALANCED_31</span>
          </div>
          <div className="flex flex-col items-start md:items-end shrink-0">
            <span className="text-[#7C8798] uppercase">Active Nodes</span>
            <span className="text-[#E6E9F2]">14 DEVICES</span>
          </div>
          <div className="flex flex-col items-start md:items-end shrink-0">
            <span className="text-[#7C8798] uppercase">GLES Status</span>
            <span className="text-[#5EA1FF]">3.0_CONTEXT_OK</span>
          </div>
        </div>
      </header>

      {/* Main Interface Split */}
      <main className={`flex-1 flex flex-col md:flex-row ${view === 'sos' ? 'overflow-y-auto md:overflow-hidden' : 'overflow-hidden'}`}>
        {view === 'radar' ? (
          <>
            {/* 3D Viewport Simulation */}
            <section className="flex-1 relative bg-black overflow-hidden border-b md:border-b-0 md:border-r border-[#2A2A2E]">
              {/* Radar Grid Overlay */}
              <div className="absolute inset-0 flex items-center justify-center opacity-20 pointer-events-none">
                <div className="w-[200vw] h-[200vw] sm:w-[600px] sm:h-[600px] border border-[#00FF41] rounded-full flex items-center justify-center">
                  <div className="w-[133vw] h-[133vw] sm:w-[400px] sm:h-[400px] border border-[#00FF41] rounded-full flex items-center justify-center">
                    <div className="w-[66vw] h-[66vw] sm:w-[200px] sm:h-[200px] border border-[#00FF41] rounded-full"></div>
                  </div>
                </div>
                <div className="absolute w-px h-full bg-[#00FF41]"></div>
                <div className="absolute h-px w-full bg-[#00FF41]"></div>
              </div>

              {/* GLES Particle Emulation */}
              <div className="absolute top-1/4 left-1/3 flex flex-col items-center">
                <div className="w-6 h-6 bg-[#00FF41] rounded-full animate-pulse shadow-[0_0_15px_#00FF41]"></div>
                <span className="text-[9px] mt-2 bg-black/60 px-1 border border-[#00FF41] whitespace-nowrap">WH-1000XM4 // -42dBm</span>
              </div>

              <div className="absolute top-1/2 right-1/4 flex flex-col items-center opacity-60">
                <div className="w-4 h-4 bg-[#3B82F6] rounded-full shadow-[0_0_10px_#3B82F6]"></div>
                <span className="text-[9px] mt-2 bg-black/60 px-1 border border-[#3B82F6] whitespace-nowrap">UNKNOWN // -68dBm</span>
              </div>

              <div className="absolute bottom-1/4 left-1/2 flex flex-col items-center">
                <div className="w-8 h-8 bg-white rounded-full shadow-[0_0_20px_white]"></div>
                <span className="text-[9px] mt-2 bg-black/60 px-1 border border-white whitespace-nowrap">MOTO_TAG // -31dBm</span>
              </div>

              {/* Camera Controls Overlay */}
              <div className="absolute bottom-4 left-4 md:bottom-6 md:left-6 flex space-x-2">
                <button className="w-8 h-8 md:w-10 md:h-10 text-xs md:text-sm border border-[#2A2A2E] bg-[#121214]/80 flex items-center justify-center hover:bg-[#2A2A2E] cursor-pointer">Z+</button>
                <button className="w-8 h-8 md:w-10 md:h-10 text-xs md:text-sm border border-[#2A2A2E] bg-[#121214]/80 flex items-center justify-center hover:bg-[#2A2A2E] cursor-pointer">Z-</button>
                <button className="w-8 h-8 md:w-10 md:h-10 text-xs md:text-sm border border-[#2A2A2E] bg-[#121214]/80 flex items-center justify-center hover:bg-[#2A2A2E] cursor-pointer">ROT</button>
              </div>
            </section>

            {/* Data Sidebar */}
            <aside className="w-full md:w-80 h-1/3 md:h-auto bg-[#121214] flex flex-col shrink-0">
              <div className="p-2 md:p-4 border-b border-[#2A2A2E] flex justify-between items-center shrink-0">
                <span className="text-xs font-bold text-[#888] uppercase">Device Feed</span>
                <span className="text-[10px] text-[#00FF41]">LIVE</span>
              </div>
              <div className="flex-1 overflow-y-auto space-y-1 p-2">
                {devices.length === 0 && (
                  <div className="text-[#888] text-center mt-4 text-[10px]">No devices added yet.<br/>Click "ADD AUDIO/BT DEVICE" to scan.</div>
                )}
                {devices.map((device, idx) => (
                  <div key={device.id} className="bg-[#1A1A1D] border-l-2 border-[#00FF41] p-3 text-[11px] cursor-pointer hover:bg-[#202024]">
                    <div className="flex justify-between">
                      <span className="text-white font-bold">{device.name}</span>
                      <span className="text-[#00FF41]">{device.rssi}dBm</span>
                    </div>
                    <div className="text-[#888] mt-1">{device.id.substring(0, 16)}...</div>
                    <div className="flex justify-between mt-2 text-[9px]">
                      <span className="text-[#3B82F6]">DIST: ~{device.distance}m</span>
                      <span className="text-[#666]">Active</span>
                    </div>
                  </div>
                ))}
              </div>
            </aside>
          </>
        ) : view === 'hub' ? (
          <>
            <section className="flex-1 relative bg-[#12141F] overflow-hidden border-b md:border-b-0 md:border-r border-[#232838] flex flex-col">
              <div className="p-2 md:p-4 border-b border-[#232838] flex justify-between items-center bg-[#171A26]">
                <span className="text-xs font-bold text-[#7C8798] uppercase">P2P Chat Offline</span>
                <span className="text-[10px] text-[#5EA1FF]">WSS://CONNECTED</span>
              </div>
              {peerSosData && (
                <div className="bg-[#EF4444]/10 border-b-2 border-[#EF4444] shrink-0">
                  <div
                    className="px-3 py-1.5 flex items-center justify-between gap-2 cursor-pointer"
                    onClick={() => setSosPanelExpanded(v => !v)}
                  >
                    <span className="text-[10px] text-[#EF4444] font-bold whitespace-nowrap">🚨 SOS {peerSosData.date} {peerSosData.time} · ±{peerSosData.acc.toFixed(0)}m</span>
                    <div className="flex items-center gap-2 shrink-0">
                      <a href={`https://www.google.com/maps/search/?api=1&query=${peerSosData.lat},${peerSosData.lng}`} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()} className="text-[10px] text-[#EF4444] border border-[#EF4444] px-2 py-0.5 whitespace-nowrap">
                        MAPA
                      </a>
                      <span className="text-[#EF4444] text-[10px]">{sosPanelExpanded ? '▲' : '▼'}</span>
                    </div>
                  </div>
                  {sosPanelExpanded && (
                    <div className="px-3 pb-2 text-[10px] text-white space-y-0.5">
                      <div>Lat: {peerSosData.lat.toFixed(6)}</div>
                      <div>Lng: {peerSosData.lng.toFixed(6)}</div>
                    </div>
                  )}
                </div>
              )}
              <div className="flex-1 overflow-y-auto p-4 space-y-3 hide-scrollbar">
                {chatMessages?.length === 0 && (
                  <div className="text-[#7C8798] text-center mt-4 text-[10px] opacity-70">Nenhuma mensagem. Inicie o chat offline.</div>
                )}
                {chatMessages?.map((msg, i) => {
                  const isSos = msg.text.startsWith("🚨EMERGENCIA🚨");
                  return (
                    <div key={i} className={`flex ${msg.sender === 'Me' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`rounded p-2 min-w-[100px] max-w-[80%] border ${msg.sender === 'Me' ? 'bg-[#5EA1FF]/10 border-[#5EA1FF] text-[#E6E9F2]' : 'bg-white/[0.03] border-[#232838] text-[#7C8798]'}`}>
                        <div className="text-[9px] mb-1 opacity-70">{msg.sender === 'Me' ? 'Você' : 'Parceiro'}</div>
                        {isSos ? (
                          <div className="text-sm text-[#EF4444] font-bold">
                            🚨 SOS RECEBIDO 🚨<br/>
                            {msg.text.split("|").slice(1).map((part, idx) => (
                              <div key={idx} className="text-xs font-normal text-white mt-1">
                                {idx === 0 && `Lat: ${part}`}
                                {idx === 1 && `Lng: ${part}`}
                                {idx === 2 && `Precisão: ${part}m`}
                                {idx === 3 && `Horário: ${part}`}
                              </div>
                            ))}
                            {msg.text.split("|").length > 2 && (
                              <a href={`https://www.google.com/maps/search/?api=1&query=${msg.text.split("|")[1]},${msg.text.split("|")[2]}`} target="_blank" rel="noreferrer" className="block mt-2 rounded text-center bg-[#EF4444]/20 border border-[#EF4444] text-[#EF4444] py-1 text-xs">
                                ABRIR NO MAPA
                              </a>
                            )}
                          </div>
                        ) : (
                          <div>
                            <div className="flex justify-between items-start gap-2">
                              <div className="text-sm">{msg.text}</div>
                              {msg.sender === 'Me' && (
                                <button onClick={() => deleteChatMessage(i)} className="text-[#EF4444] text-[10px] hover:underline shrink-0">EXCLUIR</button>
                              )}
                            </div>
                            {msg.file && msg.file.isAudio && msg.file.url && (
                              <audio controls preload="metadata" src={msg.file.url} className="block mt-1.5 h-8" style={{ width: 220 }} />
                            )}
                            {msg.file && !msg.file.isAudio && (
                              <div className="mt-2 text-xs border border-[#232838] p-2 bg-black rounded flex flex-col gap-2">
                                <div className="flex justify-between items-center">
                                  <span className="text-[#5EA1FF] truncate pr-2">{msg.file.name}</span>
                                  <a href={msg.file.url || `http://${window.location.hostname}:8000/download/${msg.file.name}`} download className="text-[#E6E9F2] hover:underline shrink-0 font-bold">BAIXAR</a>
                                </div>
                                {msg.file.isImage && msg.file.url && (
                                  <img src={msg.file.url} alt={msg.file.name} className="w-full max-h-40 object-contain rounded" />
                                )}
                              {msg.file.isVideo && msg.file.url && (
                                <video 
                                  controls 
                                  playsInline
                                  src={msg.file.url} 
                                  className="w-full max-h-40 object-contain rounded bg-black" 
                                  onClick={(e) => e.stopPropagation()}
                                  onPlay={(e) => e.stopPropagation()}
                                />
                              )}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="p-2 md:p-4 border-t border-[#232838] flex items-center gap-2">
                <input 
                  type="text" 
                  value={chatInput} 
                  onChange={e => setChatInput(e.target.value)} 
                  onKeyDown={e => e.key === 'Enter' && sendChatMessage()} 
                  disabled={isRecording}
                  className="flex-1 bg-black border border-[#232838] rounded px-3 py-2 text-sm focus:outline-none focus:border-[#5EA1FF] text-[#E6E9F2] placeholder:text-[#7C8798] disabled:opacity-40" 
                  placeholder={isRecording ? `Gravando... ${String(Math.floor(recordingSeconds / 60)).padStart(2,'0')}:${String(recordingSeconds % 60).padStart(2,'0')}` : "Mensagem..."} 
                />
                <button
                  type="button"
                  onClick={toggleRecording}
                  title={isRecording ? "Parar e enviar áudio" : "Gravar mensagem de voz"}
                  className={`shrink-0 rounded border px-4 h-[38px] flex items-center justify-center transition-colors cursor-pointer ${isRecording ? 'bg-[#EF4444]/15 border-[#EF4444] text-[#EF4444] animate-pulse' : 'bg-[#F5B940]/12 border-[#F5B940] text-[#F5B940] hover:bg-[#F5B940]/25'}`}
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3Z"/><path d="M19 11a1 1 0 0 0-2 0 5 5 0 0 1-10 0 1 1 0 0 0-2 0 7 7 0 0 0 6 6.92V20H9a1 1 0 0 0 0 2h6a1 1 0 0 0 0-2h-2v-2.08A7 7 0 0 0 19 11Z"/></svg>
                </button>
                <button 
                  onClick={sendChatMessage} 
                  disabled={isRecording}
                  className="shrink-0 rounded bg-[#5EA1FF]/12 text-[#5EA1FF] border border-[#5EA1FF] px-4 h-[38px] hover:bg-[#5EA1FF]/25 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  ENVIAR
                </button>
              </div>
            </section>
            
            <aside className="w-full md:w-80 h-1/3 md:h-auto bg-[#12141F] flex flex-col shrink-0">
              <div className="p-2 md:p-4 border-b border-[#232838] flex justify-between items-center shrink-0">
                <span className="text-xs font-bold text-[#7C8798] uppercase">File Transfer</span>
                <span className="text-[10px] text-[#F5B940]">HTTP://8000</span>
              </div>
              <div className="p-4 border-b border-[#232838] space-y-2">
                <div className="flex flex-col gap-2 mb-4 text-[10px]">
                  <a href="/radar-hub-project.zip" download className="w-full text-center rounded bg-[#2DE1E6]/8 text-[#2DE1E6] border border-[#2DE1E6] py-2 hover:bg-[#2DE1E6]/20 font-bold transition-colors">
                    [BAIXAR PROJETO COMPLETO]
                  </a>
                  <div className="flex gap-2">
                    <a href="/server.py" download className="flex-1 text-center rounded bg-transparent text-[#7C8798] border border-[#232838] py-1 hover:bg-[#232838] transition-colors">DL SERVER.PY</a>
                    <a href="/hotspot.sh" download className="flex-1 text-center rounded bg-transparent text-[#7C8798] border border-[#232838] py-1 hover:bg-[#232838] transition-colors">DL HOTSPOT.SH</a>
                  </div>
                </div>
                <label htmlFor="file-upload" className="block w-full text-center rounded bg-[#F5B940]/10 text-[#F5B940] border border-[#F5B940] py-2 cursor-pointer hover:bg-[#F5B940]/25 transition-colors">
                  + UPLOAD ARQUIVO
                  <input id="file-upload" type="file" style={{ display: 'none' }} onChange={uploadFile} />
                </label>
              </div>
              <div className="flex-1 overflow-y-auto space-y-1 p-2">
                {files?.map((fileObj, idx) => {
                  const fileName = fileObj.name || fileObj;
                  return (
                    <div key={idx} className="bg-[#171A26] rounded border-l-2 border-[#F5B940] p-3 text-[11px] flex flex-col gap-2">
                      <div className="flex justify-between items-center">
                        <span className="text-[#E6E9F2] truncate pr-2" title={fileName}>{fileName}</span>
                        <div className="flex gap-2">
                          <a href={fileObj.url || `http://${window.location.hostname}:8000/download/${fileName}`} download className="text-[#5EA1FF] hover:underline shrink-0">BAIXAR</a>
                          <button onClick={() => deleteFile(fileName)} className="text-[#EF4444] hover:underline shrink-0">EXCLUIR</button>
                        </div>
                      </div>
                      {fileObj.isImage && fileObj.url && (
                        <div className="mt-2 rounded overflow-hidden border border-[#232838]">
                          <img src={fileObj.url} alt={fileName} className="w-full max-h-32 object-contain bg-black" />
                        </div>
                      )}
                      {fileObj.isAudio && fileObj.url && (
                        <audio controls preload="metadata" src={fileObj.url} className="w-full h-8" />
                      )}
                      {fileObj.isVideo && fileObj.url && (
                        <div className="mt-2 rounded overflow-hidden border border-[#232838]">
                          <video 
                            controls 
                            playsInline
                            src={fileObj.url} 
                            className="w-full max-h-32 object-contain bg-black" 
                            onClick={(e) => e.stopPropagation()}
                            onPlay={(e) => e.stopPropagation()}
                          />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </aside>
          </>
        ) : (
          <>
            <section className="flex-1 shrink-0 relative bg-[#0A0A0B] md:overflow-y-auto border-b md:border-b-0 md:border-r border-[#2A2A2E] flex flex-col p-4 md:p-8">
              <div className="max-w-2xl mx-auto w-full space-y-8">
                <div className="text-center space-y-4">
                  <h2 className="text-2xl font-bold text-[#EF4444] tracking-widest uppercase">Módulo de Emergência</h2>
                  <p className="text-[#888] text-sm">
                    {networkStatus.internet 
                      ? "MODO ONLINE: A localização será transmitida em tempo real." 
                      : "MODO OFFLINE: A localização será enviada via SMS pelos contatos locais."}
                  </p>
                </div>

                <div className="flex flex-col items-center gap-4">
                  <label className="flex items-center gap-2 text-xs text-[#888] cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={sosBroadcastToChat}
                      disabled={sosActive}
                      onChange={(e) => setSosBroadcastToChat(e.target.checked)}
                      className="w-4 h-4 accent-[#EF4444]"
                    />
                    Compartilhar minha localização no chat P2P durante o SOS
                  </label>
                  {!sosActive ? (
                    <button 
                      onClick={activateSOS}
                      className="w-48 h-48 md:w-64 md:h-64 rounded-full border-4 border-[#EF4444] bg-[#EF4444]/10 hover:bg-[#EF4444]/20 flex items-center justify-center cursor-pointer transition-all active:scale-95 shadow-[0_0_30px_rgba(239,68,68,0.3)] hover:shadow-[0_0_50px_rgba(239,68,68,0.5)]"
                    >
                      <span className="text-3xl md:text-4xl font-bold text-[#EF4444]">ATIVAR<br/>SOS</span>
                    </button>
                  ) : (
                    <button 
                      onClick={stopSOS}
                      className="w-48 h-48 md:w-64 md:h-64 rounded-full border-4 border-[#888] bg-[#2A2A2E]/50 hover:bg-[#2A2A2E] flex items-center justify-center cursor-pointer transition-all active:scale-95 shadow-[0_0_15px_rgba(255,255,255,0.1)]"
                    >
                      <span className="text-3xl md:text-4xl font-bold text-white">CANCELAR<br/>SOS</span>
                    </button>
                  )}
                  {sosActive && networkStatus.internet && (
                    <div className="flex items-center gap-2 text-xs text-[#00FF41] mt-2 animate-pulse">
                      <span className="w-2 h-2 rounded-full bg-[#00FF41]"></span>
                      TRANSMITINDO EM TEMPO REAL
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-[#121214] border border-[#2A2A2E] p-4 space-y-2">
                    <h3 className="text-xs font-bold text-[#888] uppercase mb-4">Status da Localização</h3>
                    <div className="text-sm text-white mb-2">{gpsStatus}</div>
                    {gpsData && (
                      <div className="text-xs space-y-1 text-[#00FF41]">
                        <div>Latitude: {gpsData.lat.toFixed(6)}</div>
                        <div>Longitude: {gpsData.lng.toFixed(6)}</div>
                        <div>Precisão: {gpsData.acc.toFixed(0)} metros</div>
                        <div>Horário: {gpsData.time}</div>
                        <a 
                          href={`https://www.google.com/maps/search/?api=1&query=${gpsData.lat},${gpsData.lng}`}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-block mt-2 px-3 py-1 bg-[#00FF41]/20 border border-[#00FF41] text-[#00FF41] font-bold hover:bg-[#00FF41]/40 transition-colors"
                        >
                          📍 ABRIR MEU LOCAL NO MAPA
                        </a>
                      </div>
                    )}
                    <div className="mt-4 border-t border-[#2A2A2E] pt-2">
                      <label className="text-[10px] text-[#888] block mb-1">Intervalo de Atualização (Online):</label>
                      <select 
                        value={realtimeInterval} 
                        onChange={e => setRealtimeInterval(Number(e.target.value))}
                        disabled={sosActive}
                        className="bg-black border border-[#2A2A2E] text-white text-xs p-1 w-full"
                      >
                        <option value={0}>Tempo real (sem espera)</option>
                        <option value={5}>5 segundos</option>
                        <option value={10}>10 segundos</option>
                        <option value={30}>30 segundos</option>
                        <option value={60}>1 minuto</option>
                      </select>
                    </div>
                  </div>

                  <div className="bg-[#121214] border border-[#2A2A2E] p-4 space-y-2 flex flex-col">
                    <h3 className="text-xs font-bold text-[#888] uppercase mb-4">Conectividade & Configurações</h3>
                    <div className="text-xs space-y-2">
                      <div className="flex justify-between">
                        <span>Internet:</span>
                        <span className={networkStatus.internet ? "text-[#00FF41]" : "text-[#EF4444]"}>
                          {networkStatus.internet ? "🟢 Online" : "🔴 Offline"}
                        </span>
                      </div>
                    </div>
                    
                    <div className="mt-4 border-t border-[#2A2A2E] pt-2 flex-1 flex flex-col">
                      <label className="text-[10px] text-[#888] block mb-1">Mensagem SOS Personalizada:</label>
                      <textarea
                        value={customMessage}
                        onChange={e => setCustomMessage(e.target.value)}
                        disabled={sosActive}
                        rows={3}
                        className="bg-black border border-[#2A2A2E] text-white text-xs p-2 w-full resize-none flex-1 mb-2"
                        placeholder="Ex: Preciso de ajuda urgente..."
                      />
                      
                      <div className="mt-2 border-t border-[#2A2A2E] pt-2">
                        <label className="text-[10px] text-[#888] block mb-2 uppercase">Contatos Selecionados ({emergencyContacts.filter(c => c.active).length}):</label>
                        <div className="max-h-24 overflow-y-auto space-y-1">
                          {emergencyContacts.length === 0 && (
                            <div className="text-[10px] text-[#EF4444]">Nenhum contato salvo. Adicione contatos na aba lateral.</div>
                          )}
                          {emergencyContacts.map((contact, idx) => (
                            <label key={idx} className="flex items-center gap-2 cursor-pointer p-1 hover:bg-[#2A2A2E]">
                              <input 
                                type="checkbox" 
                                checked={contact.active} 
                                onChange={() => toggleContact(idx)}
                                className="accent-[#EF4444] cursor-pointer w-3 h-3"
                              />
                              <span className={`text-[11px] ${contact.active ? 'text-white' : 'text-[#888]'}`}>{contact.name}</span>
                              <span className="text-[10px] text-[#888] ml-auto font-mono">{contact.number}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                    </div>

                    <button onClick={testSOS} className="w-full mt-4 bg-[#2A2A2E] hover:bg-[#3f3f46] text-white py-2 text-xs border border-[#3f3f46] shrink-0">
                      🧪 TESTAR SOS
                    </button>
                  </div>
                </div>
              </div>
            </section>
            
            <aside className="w-full md:w-80 h-auto md:h-full bg-[#121214] flex flex-col shrink-0">
              <div className="p-2 md:p-4 border-b border-[#2A2A2E] flex justify-between items-center shrink-0">
                <span className="text-xs font-bold text-[#888] uppercase">Contatos de Emergência</span>
                <span className="text-[10px] text-[#EF4444]">{emergencyContacts.length} SALVOS</span>
              </div>
              
              <div className="p-4 border-b border-[#2A2A2E] space-y-2">
                <input 
                  type="text" 
                  placeholder="Nome (Ex: Maria)"
                  value={newContact.name}
                  onChange={e => setNewContact({...newContact, name: e.target.value})}
                  className="w-full bg-black border border-[#2A2A2E] px-3 py-2 text-xs focus:outline-none focus:border-[#EF4444] text-white"
                />
                <input 
                  type="tel" 
                  placeholder="Número (+55...)"
                  value={newContact.number}
                  onChange={e => setNewContact({...newContact, number: e.target.value})}
                  className="w-full bg-black border border-[#2A2A2E] px-3 py-2 text-xs focus:outline-none focus:border-[#EF4444] text-white"
                />
                
                <details className="border border-[#2A2A2E] bg-black">
                  <summary className="text-[10px] text-[#888] px-3 py-2 cursor-pointer uppercase select-none hover:text-white transition-colors">
                    Ver Sugestões de Órgãos / Serviços
                  </summary>
                  <div className="h-48 overflow-y-auto p-1 space-y-1 border-t border-[#2A2A2E]">
                    {PUBLIC_AGENCIES.map(agency => (
                      <div 
                        key={agency.label} 
                        className={`p-2 text-xs flex items-center justify-between gap-2 border ${newContact.description === agency.label ? 'border-[#EF4444] bg-[#EF4444]/10' : 'border-transparent hover:bg-[#2A2A2E]'}`}
                      >
                        <div
                          className="flex-1 cursor-pointer flex flex-col gap-1"
                          onClick={() => setNewContact({...newContact, description: agency.label})}
                        >
                          <span className={`font-bold ${newContact.description === agency.label ? 'text-[#EF4444]' : 'text-white'}`}>{agency.label}</span>
                          <span className="text-[10px] text-[#888]">{agency.desc}</span>
                        </div>
                        {agency.number && (
                          <a
                            href={`tel:${agency.number}`}
                            onClick={e => e.stopPropagation()}
                            className="shrink-0 text-[10px] text-[#00FF41] border border-[#00FF41] px-2 py-1 whitespace-nowrap hover:bg-[#00FF41]/20 transition-colors"
                          >
                            📞 LIGAR
                          </a>
                        )}
                      </div>
                    ))}
                  </div>
                </details>

                <div className="flex gap-2">
                  <button 
                    onClick={addContact}
                    className="flex-1 bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444] py-2 text-xs hover:bg-[#EF4444]/40 transition-colors"
                  >
                    {editingContactIndex !== null ? 'SALVAR EDIÇÃO' : '+ ADICIONAR CONTATO'}
                  </button>
                  {editingContactIndex !== null && (
                    <button 
                      onClick={cancelEdit}
                      className="px-4 bg-transparent text-[#888] border border-[#888] py-2 text-xs hover:bg-[#888]/10 transition-colors"
                    >
                      CANCELAR
                    </button>
                  )}
                </div>
              </div>

              <div className="flex-1 overflow-y-auto space-y-2 p-2">
                {emergencyContacts.length === 0 && (
                  <div className="text-[#888] text-center mt-4 text-[10px]">Nenhum contato adicionado.</div>
                )}
                {emergencyContacts.map((contact, idx) => (
                  <div key={idx} className={`bg-[#1A1A1D] border-l-2 ${contact.active ? 'border-[#EF4444]' : 'border-[#888] opacity-50'} p-3 text-[11px] flex flex-col gap-1`}>
                    <div className="flex justify-between items-center">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input 
                          type="checkbox" 
                          checked={contact.active} 
                          onChange={() => toggleContact(idx)}
                          className="accent-[#EF4444] cursor-pointer w-3 h-3"
                        />
                        <span className={`font-bold ${contact.active ? 'text-white' : 'text-[#888]'}`}>{contact.name}</span>
                      </label>
                      <span className="text-[9px] text-[#888] uppercase">{contact.active ? 'Selecionado' : 'Não selecionado'}</span>
                    </div>
                    {contact.description && (
                      <div className="text-[#888] text-[10px] uppercase">
                        {contact.description}
                      </div>
                    )}
                    <div className="flex justify-between items-center">
                      <span className="text-[#888] font-mono">{contact.number}</span>
                      <div className="flex gap-3">
                        <button onClick={() => editContact(idx)} className="text-xs text-[#3B82F6] hover:underline">
                          Editar
                        </button>
                        <button onClick={() => removeContact(idx)} className="text-xs text-[#EF4444] hover:underline">
                          Remover
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </aside>
          </>
        )}
      </main>

      {/* Bottom Diagnostics Console */}
      <footer className={`${showLogs ? 'h-20 md:h-24' : 'h-auto md:h-auto'} bg-[#000] border-t border-[#2A2A2E] p-2 md:p-4 flex flex-col md:flex-row font-mono text-[10px] shrink-0`}>
        {showLogs && (
          <div className="flex-1 overflow-y-auto text-[#00FF41]/70 leading-tight pr-2 md:pr-4 mb-2 md:mb-0">
            {logs.map((log, i) => (
              <p key={i} className="mb-0.5">{log}</p>
            ))}
          </div>
        )}
        <div className="w-full md:w-48 border-t md:border-t-0 md:border-l border-[#2A2A2E] pt-2 md:pt-0 md:ml-auto md:pl-4 space-y-2 shrink-0 flex flex-row md:flex-col justify-between items-center md:items-stretch">
          <div className="flex flex-row md:flex-col gap-4 md:gap-0 text-xs md:text-[10px] w-full md:w-auto overflow-x-auto hide-scrollbar">
            <div className="text-[#888] uppercase mb-0 md:mb-2 shrink-0 hidden md:block">Termux Stats</div>
            <div className="flex md:justify-between items-center gap-1 shrink-0"><span>CPU</span><span className="text-white">14%</span></div>
            <div className="flex md:justify-between items-center gap-1 shrink-0"><span>MEM</span><span className="text-white">128MB</span></div>
            <div className="flex md:justify-between items-center gap-1 shrink-0"><span>BAT</span><span className="text-[#00FF41]">88%</span></div>
          </div>
          <div 
            onClick={() => setShowLogs(!showLogs)}
            className="px-4 py-1.5 md:mt-4 text-center border border-[#2A2A2E] text-white hover:bg-[#2A2A2E] cursor-pointer shrink-0"
          >
            LOGCAT {showLogs ? '-V' : 'OFF'}
          </div>
        </div>
      </footer>
    </div>
  );
}
